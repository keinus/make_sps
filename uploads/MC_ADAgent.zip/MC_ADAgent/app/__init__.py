"""Logger 초기화"""
from logging import Logger, getLogger
from app.internal.logger import intialize_logger


app_name: str = 'aas-service'  # 어플리케이션 이름
ano_name: str = 'anomaly-detection'  # 이상탐지 이름
rssi_name: str = 'rssi-detection'  # 위협탐지 이름

logger: Logger = getLogger(app_name)  # 어플리케이션 로거
loggers = Logger = getLogger(ano_name)  # 이상탐지 로거
rssi_loggers = Logger = getLogger(rssi_name)  # 위협탐지 로거
intialize_logger(ano_name, rssi_name)  # 로거 초기화
