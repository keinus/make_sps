"""로거 등록 및 설정"""
import time
import logging
import logging.handlers
from logging import Formatter
from datetime import datetime


def get_utc_now() -> datetime:
    """UTC 기준 현재 시 반환 메서드

    Returns:
        datetime: 현재 UTC Time
    """
    utc_now: datetime = datetime.utcnow()
    utc_now = utc_now.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

    return utc_now


def intialize_logger(anoname: str, rssiname: str) -> None:
    """로거 초기화

    기본 로거를 설정하고 어플리케이션, 이상탐지, 위협탐지 로거를 생성하여 설정한다.
    로깅 디폴트 값을 수정하여 불필요한 로그가 기록 되는 것을 방지한다.
    기록되는 로그는 각 파일의 .log 파일에 저장된다.

    Args:
        anoname (str): 이상탐지 로거 이름
        rssiname (str): 위협탐지 로거 이름
    """
    logging.Formatter.converter = time.gmtime
    log_format: Formatter = Formatter(
        '{"@timestamp":"%(asctime)s.%(msecs)03dZ", "loggingtime": "%(asctime)s.%(msecs)03dZ", '
        '"process": "%(process)d", "level": "%(levelname)s", "module": "%(module)s", '
        '"funcName": "%(funcName)s", "lineno": "%(lineno)d", "message": "%(message)s",' 
        '"name": "%(name)s", "pathname": "%(pathname)s", "filename": "%(filename)s", '
        '"thread": "%(thread)s", "threadName": "%(threadName)s", "processName": "%(processName)s"}',
        datefmt="%Y-%m-%dT%H:%M:%S"
    )
    ano_log_format: Formatter = Formatter(
        '%(message)s'
    )
    rssi_log_format: Formatter = Formatter(
        '%(message)s'
    )
    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(log_format)

    file_debug_handler: logging.handlers.RotatingFileHandler = \
        logging.handlers.RotatingFileHandler(
            './app/log/application.log', 'a', 1024*1024*1024, 5)
    file_debug_handler.setLevel(logging.INFO)
    file_debug_handler.setFormatter(log_format)

    file_handler: logging.handlers.RotatingFileHandler = \
        logging.handlers.RotatingFileHandler(
            "./app/log/anomaly.log", 'a', 1024 * 1024 * 1024 * 5
        )
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(ano_log_format)

    rssi_file_handler: logging.handlers.RotatingFileHandler = \
        logging.handlers.RotatingFileHandler(
            "./app/log/anomaly_rssi.log", 'a', 1024 * 1024 * 1024 * 5
        )
    rssi_file_handler.setLevel(logging.INFO)
    rssi_file_handler.setFormatter(rssi_log_format)

    logging.basicConfig(level=logging.INFO, handlers=[
                        file_debug_handler, console_handler])

    loggers: logging.Logger = logging.getLogger(anoname)
    loggers.setLevel(logging.INFO)
    loggers.addHandler(file_handler)

    rssi_loggers: logging.Logger = logging.getLogger(rssiname)
    rssi_loggers.setLevel(logging.INFO)
    rssi_loggers.addHandler(rssi_file_handler)

    logging.getLogger("pika").setLevel(logging.WARNING)  # pika 로깅 레벨 변경
