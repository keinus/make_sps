"""예외 클래스 모듈"""


class NotFoundException(Exception):
    """데이터 없음 예외
    """


class DuplicateException(Exception):
    """중복 데이터 예외
    """
