"""파일 tailing 모듈"""
from typing import Callable
from io import TextIOWrapper
import os
import pickle
import time
import pika
from pika.exceptions import AMQPHeartbeatTimeout, AMQPConnectionError, StreamLostError
from pika.adapters.blocking_connection import BlockingChannel
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent
from app import logger


class Tailer(object):
    """파일 테일링 클래스
    """
    def __init__(self,
                 filename: str = None,
                 encoding: str = "utf-8",
                 end: bool = True) -> None:
        """초기화함수

        클래스를 초기화한다.

        Args:
            filename (str, optional): 파일명. Defaults to None.
            encoding (str, optional): 파일 인코딩 타입. Defaults to "utf-8".
            end (bool, optional): 마지막부터 읽을건지 여부. Defaults to True.
        """
        self.path: str = os.getcwd() + "/app/log/"  # 로그 파일 위치 경로
        self.is_running: bool = False  # 파일 테일러 동작 여부
        self.newlines: list = ['\n', '\r', '\r\n']  # 해당 리스트에 속한 문자는 띄어쓰기로 인식
        self.open(self.path + filename, encoding=encoding, end=end)  # tail 파일 오픈
        self.filename: str = self.path + filename  # 로그 파일의 위치와 파일명
        self.encoding: str = encoding  # 파일 인코딩 타입
        self.is_reopen: bool = False  # 파일을 다시 열건지 확인하는 변수
        self.pivot_filename: str = self.filename + ".pk"  # 로그 파일의 위치와 파일명의 pk 파일명

        try:
            if os.path.exists(self.pivot_filename):
                pivot: pickle = self.load_pivot()  # pivot 정보 불러오기
                self.seek(pivot, 0)  # 파일 포인터 위치 지정
        except EOFError:
            pass

    def reopen(self) -> None:
        """파일 다시 열기

        기존 설정 정보를 가지고 파일을 다시 연다.
        """
        self.is_reopen = True

    def seek(self, offset: int, whence: int = 0) -> None:
        """파일 포인터 위치 이동 함수

        파일 포인터의 위치를 지정한 위치로 이동한다.

        Args:
            offset (int): 위치 offset
            whence (int, optional): 위치 지정자. Defaults to 0.
        """
        self.file.seek(offset, whence)

    def seek_first(self) -> None:
        """파일 포인터를 맨 앞으로 이동

        파일 포인터를 맨 앞으로 이동한다.
        """
        self.seek(0, 0)

    def seek_end(self) -> None:
        """파일 포인터를 맨 뒤로 이동

        파일 포인터를 맨 뒤로 이동한다.
        """
        self.seek(0, 2)

    def open(self,
             filename: str = None,
             encoding: str = "utf-8",
             end: bool = True) -> None:
        """tail 대상 파일 open

        tail 대상 파일을 open한다.

        Args:
            filename (str, optional): 대상 파일 명. Defaults to None.
            encoding (str, optional): 인코딩 종류. Defaults to "utf-8".
            end (bool, optional): 마지막부터 읽을건지 여부. Defaults to True.
        """
        self.file: TextIOWrapper = open(filename, "r", encoding=encoding)
        if end:
            self.seek_end()
        else:
            self.seek_first()

    def follow(self, delay: float = 1.0) -> str:
        """파일 tail 함수

        파일을 읽어들이는 함수이다.
        기본적으로 추가적인 라인이 들어올 때까지 delay초마다 쉬면서 무한 루프를 돈다.
        일단, 현재 파일 포인터의 위치를 저장한다.
        파일에서 현재 라인을 읽는다.
        만약 readline으로 읽은 라인에 개행이 있을 경우 해당 문자를 삭제한다.
        읽은 라인을 리턴한다.
        만약 새 행이 없을 경우, 원래 파일 포인터 위치로 돌아가고 1초간 슬립한다.

        Args:
            delay (float, optional): 추가 line이 없을 경우 대기 시간. Defaults to 1.0.

        Returns:
            str: 읽어드린 라인 리턴
        """
        self.is_running = True

        while self.is_running:
            pivot = self.file.tell()
            self.save_pivot(pivot)
            line = self.file.readline()

            if line:
                if line[-1] in self.newlines:
                    line = line[:-1]
                    if line[-1:] == '\r\n' and '\r\n' in self.newlines:
                        line = line[:-1]
                return line

            else:
                self.file.seek(pivot)
                time.sleep(delay)
                if self.is_reopen:
                    self.open(self.filename, self.encoding, False)

    def stop(self) -> None:
        """동작 종료

        동작을 종료한다.
        파일을 닫는다.
        """
        self.is_running = False
        self.file.close()

    def save_pivot(self, pivot: int) -> None:
        """pivot 정보 저장

        현재 파일의 포인터인 pivot 정보를 저장한다.

        Args:
            pivot (int): 파일 포인터
        """
        with open(self.pivot_filename, 'wb') as pivot_fp:
            pickle.dump(pivot, pivot_fp)

    def load_pivot(self) -> int:
        """pivot 정보 불러오기

        파일에서 pivot 정보를 가져와 리턴한다.

        Returns:
            int: pivot 값
        """
        with open(self.pivot_filename, 'rb') as pivot_fp:
            return pickle.load(pivot_fp)


class Handler(FileSystemEventHandler):
    """observer의 메시지 핸들러 클래스

    watchdoc의 메시지를 FileTailer 클래스에서 처리하도록하기 위해
    핸들러를 설정하고 메시지 발생 시 해당 핸들러를 호출한다.
    """

    def __init__(self, handler: Callable) -> None:
        """초기화 함수

        핸들러를 설정한다.

        Args:
            handler (Callable): 메시지 핸들러
        """
        self.handler = handler  # 핸들러

    def on_any_event(self, event: FileSystemEvent) -> None:
        """이벤트 핸들러

        이벤트 발생 시 호출되는 함수로 내장 핸들러를 호출한다.

        Args:
            event (FileSystemEvent): 이벤트
        """
        self.handler(type_=event.event_type, src_path=event.src_path,
                     _is_directory=event.is_directory)


class FileTailer(object):
    """Tailer의 wrapper 클래스
    """
    tailer: Tailer = None  # 테일러 인스턴스
    observer: Observer = None  # observer 인스턴스

    def __init__(self,
                 filename: str,
                 encoding: str = "utf-8",
                 end: bool = False) -> None:
        """초기화 함수

        Tailer 클래스를 생성하고 초기화한다.
        Observer 클래스를 생성하고 초기화한다.

        Args:
            filename (str): 파일명
            encoding (str, optional): 파일 인코딩 방식. Defaults to "utf-8".
            end (bool, optional): 파일의 끝. Defaults to False.
        """
        self.path = os.getcwd() + "/app/log/"  # 로그 저장 위치
        self.tailer = Tailer(filename, encoding, end=end)  # 테일러 생성

        self.observer = Observer()  # 옵저버 생성
        self.observer.schedule(Handler(self.handler),
                               self.path,
                               recursive=False)
        self.observer.start()  # 옵저버 시작

    def follow(self, delay: float = 1.0) -> str:
        """파일 읽기

        파일의 현재 위치에서 한줄 읽어서 리턴한다.
        마지막 줄이면 blocking.
        새 줄이 추가되면 추가된 줄을 리턴한다.

        Args:
            delay (float, optional): 대기 시간. 초. Defaults to 1.0.

        Returns:
            str: 읽은 라인
        """
        return self.tailer.follow(delay)

    def close(self) -> None:
        """닫기

        tailer를 닫는다.
        observer도 닫는다.
        """
        self.tailer.stop()
        self.observer.stop()

    def is_closed(self) -> bool:
        """파일이 현재 닫혀있는지 확인

        tailer가 연 파일이 현재 닫혀있는지 여부를 리턴한다.

        Returns:
            bool: 파일 닫힘 여부
        """
        return self.tailer.file.closed

    def handler(self, type_: str, src_path: str, _is_directory: bool) -> None:
        """파일 변화 메시지 핸들러

        파일이 변화되었을 경우 호출하는 핸들러.
        변화된 파일이 로깅 대상 파일일 경우, 해당 파일이 이동되었거나 삭제되었을 때는 tailer를 닫는다.
        대상 파일이 새로 생성되었을 경우 해당 파일을 다시 연다.

        Args:
            type (str): 이벤트 타입
            src_path (str): 파일 패스
            _is_directory (bool): 디렉토리 여부(현재는 사용하지 않는 인자)
        """
        if os.path.basename(src_path) == self.tailer.filename:
            if type_ == "created":
                self.tailer.reopen()

def initialize_rabbitmq(username: str, password: str, host: str, exchange: str) -> BlockingChannel:
    """RabbitMQ 초기화 메서드

    Args:
        username (str): RabbitMQ ID
        password (str): RabbitMQ 비밀번호
        host (str): RabbitMQ 호스트 IP
        exchange (str): RabbitMQ exchange 명

    Returns:
        BlockingChannel: RabbitMQ 채널
    """
    while True:
        try:
            rabbitmq_cred = pika.PlainCredentials(username=username, password=password)
            connection = pika.BlockingConnection(
                pika.ConnectionParameters(host=host, credentials=rabbitmq_cred)
            )
            channel = connection.channel()
            channel.exchange_declare(exchange=exchange, exchange_type='topic')
            break
        except (AMQPConnectionError, AMQPHeartbeatTimeout, StreamLostError):
            # logger.info("로그전송을 위한 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
            print("[INFO] 로그전송을 위한 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
            time.sleep(1)
            continue

    return channel


def filetailer_start(logfile_name: str, exchange: str, routing_key: str) -> None:
    """로그파일 filetailer 시작 메서드

    Args:
        logfile_name (str): 로그 파일 명
        exchange (str): rabbitmq exchange 명
        routing_key (str): rabbitmq routing_key 명
    """
    rabbitmq_channel = initialize_rabbitmq(
        username='cedt',
        password='alfoehwjs',
        host='192.168.51.4',
        exchange=exchange
    )
    tailer: FileTailer = FileTailer(logfile_name)  # 파일 테일러 객체
    while True:
        try:
            line = tailer.follow()
            if line is not None:
                rabbitmq_channel.basic_publish(
                    exchange=exchange,
                    routing_key=routing_key,
                    body=line
                )
                time.sleep(0.001)
        except (AMQPConnectionError, AMQPHeartbeatTimeout, StreamLostError):
            # logger.info("로그전송을 위한 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
            print("[INFO] 로그전송을 위한 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
            rabbitmq_channel = initialize_rabbitmq(
                username='cedt',
                password='alfoehwjs',
                host='192.168.51.4',
                exchange=exchange
            )
            # logger.info("로그전송을 위한 RabbitMQ와 연결이 복구되었습니다.")
            print("[INFO] 로그전송을 위한 RabbitMQ와 연결이 복구되었습니다.")
            continue
        except (IOError, ValueError):
            while tailer.is_closed():
                time.sleep(1)
