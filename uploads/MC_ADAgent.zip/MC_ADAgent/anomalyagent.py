"""이상 탐지 Anomalyagent 모듈"""
import json
import base64
import argparse
import time
import threading
from multiprocessing import Process
import warnings
from pika.spec import Basic, BasicProperties
from pika.exceptions import AMQPHeartbeatTimeout
from pika.adapters.blocking_connection import BlockingChannel
from pika import BlockingConnection, PlainCredentials, ConnectionParameters
import pika
from inference import Inference
from internal_ad import ThreatInference
from app import logger, file_tailer


warnings.filterwarnings('ignore')


class Anomalyagent():
    """Anomalyagent 관련 서비스

    드론 패킷 데이터를 추론하기 위해 필요한 Anomaly agent 생성하는 클래스이다.
    """

    def __init__(self, droneid: str) -> None:
        """초기화 함수

        Args:
            droneid (str): 드론 id
        """
        self.drone_id: str = droneid  # 드론 id
        self.recv_message: list = []  # rabbitmq 메세지 저장 리스트
        self.rabbitmq_cred: PlainCredentials = PlainCredentials(
            username='cedt', password='alfoehwjs')  # rabbitmq 생성
        self.conn: BlockingConnection = BlockingConnection(
            ConnectionParameters(
                host='192.168.51.4', credentials=self.rabbitmq_cred)
        )  # rabbitmq 연결 정보
        self.channel: BlockingConnection = self.conn.channel()  # rabbitmq 연결

    def __add_model(
            self, _channel: BlockingChannel, method: Basic.Deliver,
            _properties: BasicProperties, body: bytes) -> None:
        """AAS에서 받은 모델을 리스트에 추가하는 함수

        Args:
            _channel (BlockingChannel): 사용하지 않는 callback 함수 인자
            method (Basic.Deliver): 전달받은 메시지 메타데이터
            _properties (BasicProperties): 사용하지 않는 callback 함수 인자
            body (bytes): 전달받은 메시지 body
        """
        logger.info("[MODEL 수신] %s", method.routing_key)
        self.recv_message.append(body)

    def receive_start(self) -> None:
        """AAS에서 모델을 수신받는 함수

        routing_key: aas.model.{drone_id} 값을 통해 메세지를 받는다.
        메세지 안에는 드론이 사용할 모델의 byte 값이 저장되어있다.
        AAS 서비스에서 메세지를 보내면 해당 함수가 routing_key를 통해 메세지를 받고,
        __add_model 함수를 호출하며, RabbitMQ 연결이 끊기면 재연결을 시도한다.
        """
        while True:
            try:
                self.channel.exchange_declare(
                    exchange='cedt.model', exchange_type='topic')
                result = self.channel.queue_declare('', exclusive=True)
                queue_name = result.method.queue
                self.channel.queue_bind(
                    exchange='cedt.model',
                    queue=queue_name,
                    routing_key=f'aas.model.{self.drone_id}'
                )

                logger.info('[*] Waiting for Detection Model.')
                self.channel.basic_consume(
                    queue=queue_name,
                    on_message_callback=self.__add_model,
                    auto_ack=True
                )
                self.channel.start_consuming()
            except AMQPHeartbeatTimeout:
                # logger.info("모델수신 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
                print("[INFO] 모델수신 RabbitMQ와 연결이 끊겼습니다. 재연결을 시도합니다.")
                self.rabbitmq_cred = pika.PlainCredentials(
                    username='cedt', password='alfoehwjs')
                self.conn = pika.BlockingConnection(
                    pika.ConnectionParameters(
                        host='192.168.51.4', credentials=self.rabbitmq_cred)
                )
                self.channel = self.conn.channel()
                continue

    def pop_model(self) -> json:
        """리스트에 저장된 메세지를 json으로 변환하는 함수

        RabbitMQ를 통해 받은 메세지가 저장된 recv_message 리스트에서
        가장 앞에있는 0번지를 json 형식으로 변환하여 반환한다.

        Returns:
            model (json): 리턴 데이터
        """
        model = json.loads(self.recv_message.pop(0))
        return model


def get_args() -> argparse.Namespace:
    """인자값 드론 id를 받아오는 함수

    argument에 저장된 drone_id 값을 반환한다.

    Returns:
        parsers (argparse.Namespace): 리턴 데이터
    """
    parsers = argparse.ArgumentParser(description='알맞은 인자를 입력하세요.')
    parsers.add_argument('--drone_id', required=False, default='D0001')

    return parsers


def model_save(model: json) -> None:
    """모델을 저장하는 함수

    pop_model 함수가 변환해준 json 데이터를 사용한다.
    json 데이터 안에는 base64를 기반으로 인코딩된 model, pca, scaler 값들이 저장되어 있다.

    저장되어 있는 값을 다시 디코드하여 model, pca, scaler 파일을 로컬에 저장한다.

    Args:
        model (json): json 데이터
    """
    models = base64.b64decode(model['model'])
    pca = base64.b64decode(model['pca'])
    scaler = base64.b64decode(model['scaler'])

    with open('./app/model/model.pkl', 'wb') as model_file:
        model_file.write(models)
    with open('./app/model/pca.pkl', 'wb') as pca_file:
        pca_file.write(pca)
    with open('./app/model/scaler.pkl', 'wb') as scaler_file:
        scaler_file.write(scaler)


def threat_inference_run() -> None:
    """위협 신호 추론 서비스 실행 함수
    
    ThreatInference 서비스를 선언하여 위협 신호를 추론하는 함수를 실행한다.
    """
    threat_pred = ThreatInference()
    threat_pred.pred_start()


if __name__ == '__main__':
    ADA_PROCESSES: list[Process] = []  # Process 정보를 저장하는 리스트
    FILETAILER_PROCESSES: list[Process] = []  # 파일 테일러 정보를 저장하는 리스트

    parser = get_args()
    args = parser.parse_args()
    drone_id = args.drone_id

    log_proc = Process(
        target=file_tailer.filetailer_start,
        args=('application.log', 'cedt_mavlink', 'mc.aas-service.applog', )
    )
    log_proc.start()
    FILETAILER_PROCESSES.append(log_proc)
    logger.info("어플리케이션 로그 전송 프로세스(%s) 생성 및 실행", log_proc.name)

    ada = Anomalyagent(droneid=drone_id)
    ada_consumer = threading.Thread(target=ada.receive_start)
    ada_consumer.start()
    logger.info("위험징후분석기(AAS)으로부터 Model 수신 스레드(%s) 생성 및 시작", ada_consumer.name)

    while True:
        if len(ada.recv_message) > 0:
            for ada_process in ADA_PROCESSES:
                ada_process.kill()
                print(f'{ada_process.name} Kill!')
            ADA_PROCESSES.clear()

            models = ada.pop_model()
            if 'delete' in models:
                logger.info("(%s) 드론이 사용하던 기존 모델을 삭제합니다.", ada.drone_id)
                logger.info('[*] Waiting for Detection Model.')
                time.sleep(0.5)
            else:
                model_save(models)
                logger.info("수신 받은 (%s) 모델 저장 완료.", models['model_id'])

                time.sleep(0.5)
                ada_pred = Inference(drone_id)
                ada_proc = Process(target=ada_pred.pred_start)
                ADA_PROCESSES.append(ada_proc)
                logger.info("ADAgent 프로세스 (%s)을 실행합니다.", ada_proc.name)
                ada_proc.start()
                time.sleep(0.5)

                threat_proc = Process(target=threat_inference_run)
                ADA_PROCESSES.append(threat_proc)
                logger.info("Threat Agent 프로세스 (%s)을 실행합니다.", threat_proc.name)
                threat_proc.start()
            time.sleep(5)
