"""Anomalyagent 위협 신호 추론 모듈"""
import json
import pickle
import os
import socket
from multiprocessing import Process
import pandas as pd
from keras import models
from keras.models import load_model
import numpy as np
from pika import BlockingConnection, PlainCredentials, ConnectionParameters
from app import logger, file_tailer, rssi_loggers
from app.internal.logger import get_utc_now

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


class ThreatInference():
    """추론 관련 서비스

    USRP 패킷 데이터를 추론하기 위한 서비스를 제공하는 클래스이다.
    """
    def __init__(self) -> None:
        """초기화 함수

        USRP 패킷을 전달받기 위해 socket을 생성한다.
        이상 데이터가 발견되었을 경우 elasticsearch에 저장하기 위해
        file_tailer를 프로세스로 등록하고, 추론에 필요한 model, pca, scaler
        파일을 미리 load 한다.
        또한, 추론에 사용할 데이터를 조합하기 위한 packet 리스트도 미리 선언한다.
        """
        self.server_sock: socket = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM)  # AAS Service udp socket
        self.server_sock.setsockopt(
            socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # TIME_WAIT을 무시하기위한 설정
        self.client_sock: socket = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM)  # MTD Service udp socket
        self.host: str = '127.0.0.1'  # host 정보
        self.port: int = 31339  # port 정보 (31339 == RSSI Data, 31338 == mav data)
        self.server_sock.bind((self.host, self.port))  # AAS Service Bind

        threat_proc: Process = Process(
            target=file_tailer.filetailer_start,
            args=('anomaly_rssi.log', 'cedt_mavlink', 'mc.rssi-detection.anolog', )
        )
        threat_proc.start()
        logger.info("RSSI 신호 위협탐지 로그 전송 프로세스(%s) 생성 및 실행", threat_proc.name)

        self.model_path: str = './app/model/gru/model_gru_364.h5'  # model 파일 경로
        self.scaler_path: str = './app/model/gru/scaler_gru.pkl'  # scaler 파일 경로

        self.model: models = load_model(self.model_path, compile=True)  # model load
        self.model.summary()  # 모델 요약 정보
        with open(self.scaler_path, 'rb') as scaler_file:
            self.scaler: pickle = pickle.load(scaler_file)  # scaler load

        self.exchange: str = 'cedt_mavlink'  # rabbitmq exchange
        self.routing_key: str = 'rf.mav.1'  # rabbitmq 라우팅 키

        self.rabbitmq_cred: PlainCredentials = PlainCredentials(
            username='cedt', password='alfoehwjs')  # rabbitmq 생성
        self.conn: BlockingConnection = BlockingConnection(
            ConnectionParameters(
                host='192.168.51.4', credentials=self.rabbitmq_cred)
        )  # rabbitmq 연결 정보
        self.channel: BlockingConnection = self.conn.channel()  # rabbitmq 연결

    def pred_start(self) -> None:
        """USRP 패킷 데이터 추론하는 함수

        전달받은 USRP 패킷을 조합한다.
        조합하는 도중 중복 데이터가 들어오게 되면 이전 보다 큰 값이 저장된다.
        packet 리스트에 None 값이 없을 경우 추론이 시작되며, 추론 결과가
        이상 데이터로 판단될 경우 anomaly.log 파일에 해당 데이터를 저장된다.
        이때, 이상 데이터를 elasticsearch에 저장하고, MTD 서비스에 이상 데이터가
        탐지되었다고 메세지를 전송한다.
        """
        while True:
            receive_data, _ = self.server_sock.recvfrom(1024)
            datas = json.loads(receive_data.decode())
            print(datas)

            key = ['rssi', 'remrssi', 'noise', 'diff_rxerrors']
            data = {}

            for i in key:
                data[i] = datas[i]

            origin_data = pd.DataFrame(data, index=[0])
            data = pd.DataFrame(data, index=[0])

            data[['rssi', 'remrssi', 'noise', 'diff_rxerrors']] = self.scaler.transform(
                data[['rssi', 'remrssi', 'noise', 'diff_rxerrors']]
            )

            datas = data.values.reshape(data.shape[0], 1, data.shape[1]).astype(float)
            pred = self.model.predict(datas, workers=10, use_multiprocessing=False)
            pred = pred.reshape(pred.shape[0], pred.shape[2])
            pred = pd.DataFrame(pred, columns=['rssi', 'remrssi', 'noise', 'diff_rxerrors'])
            pred.index = data.index
            x_data = datas.reshape(datas.shape[0], datas.shape[2])
            mae = np.mean(np.abs(pred - x_data), axis=1)
            # print(f'mae[0]: {mae[0]}')
            # print(f'mae: {mae}')

            if mae[0] > 0.31:
                rssi_dict = {
                    'result': '주변 신호 중 위협 신호가 탐지되었습니다.',
                    'rssi': int(origin_data['rssi'][0]),
                    'remrssi': int(origin_data['remrssi'][0]),
                    'noise': int(origin_data['noise'][0]),
                    'mae': round(mae[0], 3),
                    'datatype': 'Threat'
                }

                rssi_dict['loggingtime'] = get_utc_now()
                rssi_loggers.info(
                    json.dumps(rssi_dict)
                )

                self.client_sock.sendto(
                    "Threat detection".encode(), ('127.0.0.1', 30003))
