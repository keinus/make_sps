"""Anomalyagent 패킷 데이터 추론 모듈"""
import json
import pickle
import socket
from multiprocessing import Process
import warnings
import numpy as np
from pika import BlockingConnection, PlainCredentials, ConnectionParameters
from app import logger, loggers, file_tailer
from app.internal.logger import get_utc_now


warnings.filterwarnings('ignore')


class Inference():
    """추론 관련 서비스

    드론 패킷 데이터를 추론하기 위한 서비스를 제공하는 클래스이다.
    """
    def __init__(self, drone_id: str) -> None:
        """초기화 함수

        드론 패킷을 전달받기 위해 socket을 생성한다.
        이상 데이터가 발견되었을 경우 elasticsearch에 저장하기 위해
        file_tailer를 프로세스로 등록하고, 추론에 필요한 model, pca, scaler
        파일을 미리 load 한다.
        또한, 추론에 사용할 데이터를 조합하기 위한 packet 리스트도 미리 선언한다.

        Args:
            drone_id (str): 드론 id
        """
        self.server_sock: socket = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM)  # AAS Service udp socket
        self.server_sock.setsockopt(
            socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # TIME_WAIT을 무시하기위한 설정
        self.client_sock: socket = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM)  # MTD Service udp socket
        self.host: str = '127.0.0.1'  # host 정보
        self.port: int = 31337  # port 정보
        self.server_sock.bind((self.host, self.port))  # AAS Service Bind
        self.drone_id: str = drone_id  # 드론 ID

        ano_proc: Process = Process(
            target=file_tailer.filetailer_start,
            args=('anomaly.log', 'cedt_mavlink', 'mc.ano-detection.anolog', )
        )
        ano_proc.start()
        logger.info("이상탐지 로그 전송 프로세스(%s) 생성 및 실행", ano_proc.name)

        self.model_path: str = './app/model/model.pkl'  # model 파일 경로
        self.pca_path: str = './app/model/pca.pkl'  # pca 파일 경로
        self.scaler_path: str = './app/model/scaler.pkl'  # scaler 파일 경로

        with open(self.model_path, 'rb') as model_file:
            self.model: pickle = pickle.load(model_file)  # model load

        with open(self.pca_path, 'rb') as pca_file:
            self.pca: pickle = pickle.load(pca_file)  # pca load

        with open(self.scaler_path, 'rb') as scaler_file:
            self.scaler: pickle = pickle.load(scaler_file)  # scaler load

        self.key_list: list = ['roll', 'pitch', 'yaw', 'rollspeed', 'pitchspeed', 'yawspeed',
                               'q1', 'q2', 'q3', 'q4', 'relative_alt']  # 전체 feature 리스트

        self.attitude_list: list = ['roll', 'pitch', 'yaw',
                                    'rollspeed', 'pitchspeed', 'yawspeed']  # attitude feature 리스트

        self.quaternion_list: list = ['q1', 'q2', 'q3', 'q4']  # quaternion_list feature 리스트
        
        self.globalposition_list: list = ['relative_alt']  # globalposition_list feature 리스트
        self.packet: dict = dict.fromkeys(self.key_list)  # 전체 feature를 key 값으로, value는 None으로 초기화

        self.exchange: str = 'cedt_mavlink'  # rabbitmq exchange
        self.routing_key: str = 'rf.mav.1'  # rabbitmq 라우팅 키

        self.rabbitmq_cred: PlainCredentials = PlainCredentials(
            username='cedt', password='alfoehwjs')  # rabbitmq 생성
        self.conn: BlockingConnection = BlockingConnection(
            ConnectionParameters(
                host='192.168.51.4', credentials=self.rabbitmq_cred)
        )  # rabbitmq 연결 정보
        self.channel: BlockingConnection = self.conn.channel()  # rabbitmq 연결

    def pred_start(self) -> None:
        """패킷 데이터 추론하는 함수

        전달받은 드론 패킷을 조합한다.
        조합하는 도중 중복 데이터가 들어오게 되면 이전 보다 큰 값이 저장된다.
        packet 리스트에 None 값이 없을 경우 추론이 시작되며, 추론 결과가
        이상 데이터로 판단될 경우 anomaly.log 파일에 해당 데이터를 저장된다.
        이때, 이상 데이터를 elasticsearch에 저장하고, MTD 서비스에 이상 데이터가
        탐지되었다고 detection 메세지를 전송한다.
        """
        cnt = 0

        while True:
            receive_data, _ = self.server_sock.recvfrom(1024)
            data = json.loads(receive_data.decode())

            if (None in self.packet.values()) is not True:
                if cnt > 50:
                    scaler_data = self.scaler.transform(
                        np.array(list(self.packet.values())).reshape(1, -1))

                    pca_data = self.pca.transform(scaler_data)

                    predict = self.model.predict(pca_data)
                    decision_func = self.model.decision_function(pca_data)

                    if predict == -1:
                        ano_dict = {
                            "result": "자세 데이터에 이상이 탐지되었습니다.",
                            "drone_id": self.drone_id,
                            "data": [float(i) for i in list(self.packet.values())],
                            "df": float(decision_func),
                            "predict": int(predict),
                            "datatype": "Anomaly",
                            "sysid": data['sysid'],
                            "type": 'Posture',
                            'loggingtime': get_utc_now()
                        }
                        loggers.info(json.dumps(ano_dict))

                        self.client_sock.sendto(
                            "detection".encode(), ('127.0.0.1', 30003))

                    self.packet.update({}.fromkeys(self.packet, None))
                    cnt = 0
                else:
                    cnt += 1
                    self.packet.update({}.fromkeys(self.packet, None))
            else:
                if data['mavpackettype'] not in ['ATTITUDE', 'ATTITUDE_QUATERNION', 'GLOBAL_POSITION_INT']:
                    continue
                if data['mavpackettype'] == 'ATTITUDE':
                    for col in self.attitude_list:
                        if self.packet[col] is None:
                            self.packet[col] = data[col]
                        elif self.packet[col] < data[col]:
                            self.packet[col] = data[col]
                        else:
                            continue
                if data['mavpackettype'] == 'ATTITUDE_QUATERNION':
                    for col in self.quaternion_list:
                        if self.packet[col] is None:
                            self.packet[col] = data[col]
                        elif self.packet[col] < data[col]:
                            self.packet[col] = data[col]
                        else:
                            continue
                if data['mavpackettype'] == 'GLOBAL_POSITION_INT':
                    for col in self.globalposition_list:
                        if self.packet[col] is None:
                            self.packet[col] = data[col]
                        elif self.packet[col] < data[col]:
                            self.packet[col] = data[col]
                        else:
                            continue
