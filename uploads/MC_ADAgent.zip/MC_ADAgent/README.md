```yaml
elasticsearch:  # 엘라스틱서치 설정 부분
  url: <엘라스틱서치 접속 URL, ex) https://192.168.51.3:9200>
  id: <엘라스틱서치 접속 ID>
  pw: <엘라스틱서치 접속 Password>
rabbitmq:  # RabbitMQ 설정 부분
  ip: <RabbitMQ IP, ex) 192.168.51.4>
  id: <RabbitMQ ID>
  pw: <RabbitMQ Password>
```

디폴트 설정은 아래와 같습니다.  
아래 설정을 참고하여 실제 프로젝트에서 변경하여 사용하시기 바랍니다.

```yaml
elasticsearch:
  url: https://192.168.51.3:9200
  id: elastic
  pw: alfoehwjs
rabbitmq:
  ip: 192.168.51.4
  id: cedt
  pw: alfoehwjs
```